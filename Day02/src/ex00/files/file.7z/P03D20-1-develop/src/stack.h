#ifndef STACK_H
#define STACK_H

struct stack {
    char data;
    struct stack *next;
};
struct stack *init(char data);
int empty(const struct stack *root);
char pop(struct stack **root);
void push(struct stack **root, char data);
void destroy(struct stack **root);

struct stack_dbl {
    double data;
    struct stack_dbl *next;
};
struct stack_dbl *init_dbl(double data);
int empty_dbl(const struct stack_dbl *root);
double pop_dbl(struct stack_dbl **root);
void push_dbl(struct stack_dbl **root, double data);
void destroy_dbl(struct stack_dbl **root);


#endif