#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mainlib.h"
#include "stack.h"

int main() {
    struct stack *operators = NULL;
    int k = 0, point = 0, n = 0, flag = 1;
    char *a = (char *)malloc(1 * sizeof(char));

    while (scanf("%c", &a[n]) == 1 && a[n] != '\n' && flag) {
        char *tmp = (char *)realloc(a, ++n * sizeof(char));
        if (tmp != NULL)
            a = tmp;
        else {
            printf("Memory was not allocated correctly");
            flag = 0;
        }
    }

    char outstring[strlen(a) * 2];

    while (a[k] != '\0' && flag) {
        if (a[k] == ')') {
            char t = ' ';
            while (t != '(') {
                t = pop(&operators);
                outstring[point++] = ' ';
                if (t != '(') outstring[point++] = t;
            }
        }
        if (a[k] == 'x') {
            outstring[point++] = a[k];
            outstring[point++] = ' ';
        }
        if (my_isdigit(a[k])) {
            while (my_isdigit(a[k])) {
                outstring[point++] = a[k];
                k++;
            }
            outstring[point++] = ' ';
            k--;
        }
        if (a[k] == '(') push(&operators, '(');

        if (a[k] == '+' || a[k] == '-' || a[k] == '/' || a[k] == '*' || (a[k] == 's' && a[k + 1] == 'i') ||
            (a[k] == 'c' && a[k + 1] == 'o') || (a[k] == 't' && a[k + 1] == 'a') ||
            (a[k] == 'c' && a[k + 1] == 't') || (a[k] == 's' && a[k + 1] == 'q') ||
            (a[k] == 'l' && a[k + 1] == 'n')) {
            if ((a[k] == '-' && k == 0) || (a[k] == '-' && a[k - 1] == '(')) {
                outstring[point++] = '0';
                outstring[point++] = ' ';
            }

            if (operators == NULL) {
                if ((a[k] == 's' && a[k + 1] == 'i') || (a[k] == 'c' && a[k + 1] == 'o') ||
                    (a[k] == 't' && a[k + 1] == 'a') || (a[k] == 'c' && a[k + 1] == 't') ||
                    (a[k] == 's' && a[k + 1] == 'q') || (a[k] == 'l' && a[k + 1] == 'n')) {
                    push(&operators, a[k + 1]);
                } else
                    push(&operators, a[k]);

            } else if (priority(operators->data) < priority(a[k])) {
                if (priority(a[k]) == 5) {
                    int counter = 0;
                    while (a[k] != '(') {
                        if (counter == 1) push(&operators, a[k]);
                        k++;
                        counter++;
                    }
                    k--;
                } else
                    push(&operators, a[k]);

            } else {
                while ((operators != NULL) && (priority(operators->data) >= priority(a[k]))) {
                    outstring[point++] = pop(&operators);
                    outstring[point++] = ' ';
                }
                push(&operators, a[k]);
            }
        }
        k++;
    }

    while (operators != NULL) {
        char wt = pop(&operators);
        if (wt != '(') {
            outstring[point++] = wt;
            outstring[point++] = ' ';
        }
    }
    outstring[point] = '\0';
    build_graph(outstring);
    free(a);
    destroy(&operators);

    return 0;
}