#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

struct stack *init(char data) {
    struct stack *new = malloc(sizeof(struct stack));
    new->data = data;
    new->next = NULL;
    return new;
}
int empty(const struct stack *root) { return root == NULL ? 1 : 0; }
char pop(struct stack **root) {
    char res;
    if (empty(*root))
        res = ' ';
    else {
        struct stack *temp = *root;
        *root = (*root)->next;
        res = temp->data;
        free(temp);
    }
    return res;
}
void push(struct stack **root, char data) {
    struct stack *new = init(data);
    new->next = *root;
    *root = new;
}
void destroy(struct stack **root) {
    while (!empty(*root)) pop(root);
}

struct stack_dbl *init_dbl(double data) {
    struct stack_dbl *new = malloc(sizeof(struct stack_dbl));
    new->data = data;
    new->next = NULL;
    return new;
}
int empty_dbl(const struct stack_dbl *root) { return root == NULL ? 1 : 0; }
double pop_dbl(struct stack_dbl **root) {
    double res;
    if (empty_dbl(*root))
        res = -5;
    else {
        struct stack_dbl *temp = *root;
        *root = (*root)->next;
        res = temp->data;
        free(temp);
    }
    return res;
}
void push_dbl(struct stack_dbl **root, double data) {
    struct stack_dbl *new = init_dbl(data);
    new->next = *root;
    *root = new;
}
void destroy_dbl(struct stack_dbl **root) {
    while (!empty_dbl(*root)) pop_dbl(root);
}
