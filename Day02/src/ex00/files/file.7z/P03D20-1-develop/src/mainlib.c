#include "mainlib.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stack.h"

/* Функция PRIOR возвpащает пpиоpитет аpифм. опеpации */
int priority(char ch) {
    // printf("ch=%c\n", ch);
    int ans = 0;
    struct pri_op array[] = {{'(', 0}, {'+', 3}, {'-', 3}, {'*', 4}, {'/', 4},
                             {'s', 5}, {'c', 5}, {'t', 5}, {'l', 5}};
    for (int i = 0; i < 9; i++) {
        if (ch == array[i].operator) ans = array[i].priority;
    }

    return ans;
}

// проверка на число
int my_isdigit(char ch) {
    int flag = 0;
    if ((ch >= '0') && (ch <= '9')) flag = 1;

    return flag;
}

double calculate(char *expression, double x) {
    char str[strlen(expression)];
    strcpy(str, expression);
    struct stack_dbl *num_stack = NULL;
    char *a = strtok(str, " ");

    while (a != NULL) {
        if (my_isdigit(a[0])) {
            char *ptr;
            double n = strtod(a, &ptr);
            push_dbl(&num_stack, n);
        } else if (!strcmp(a, "x")) {
            push_dbl(&num_stack, x);

        } else if (!strcmp(a, "i") || !strcmp(a, "o") || !strcmp(a, "a") || !strcmp(a, "t") ||
                   !strcmp(a, "q") || !strcmp(a, "n")) {
            char ch = a[0];
            double n = pop_dbl(&num_stack);
            switch (ch) {
                case 'i':
                    push_dbl(&num_stack, sin(n));
                    break;
                case 'o':
                    push_dbl(&num_stack, cos(n));
                    break;
                case 'a':
                    push_dbl(&num_stack, tan(n));
                    break;
                case 't':
                    push_dbl(&num_stack, 1. / tan(n));
                    break;
                case 'q':
                    push_dbl(&num_stack, sqrt(n));
                    break;
                case 'n':
                    push_dbl(&num_stack, log10(n));
                    break;
            }
        } else if (!strcmp(a, "+") || !strcmp(a, "-") || !strcmp(a, "*") || !strcmp(a, "/")) {
            char ch = a[0];
            double b = pop_dbl(&num_stack), c = pop_dbl(&num_stack);
            switch (ch) {
                case '+':
                    push_dbl(&num_stack, c + b);
                    break;
                case '-':
                    push_dbl(&num_stack, c - b);
                    break;
                case '*':
                    push_dbl(&num_stack, c * b);
                    break;
                case '/':
                    push_dbl(&num_stack, c / b);
                    break;
            }
        }
        a = strtok(NULL, " ");
    }
    double res = pop_dbl(&num_stack);
    destroy_dbl(&num_stack);
    return res;
}

void build_graph(char *expression) {
    double values[WIDTH];
    double x = 0, dx = (4 * M_PI) / (WIDTH - 1), dy = 1. / 12;
    for (int i = 0; i < WIDTH; i++) {
        values[i] = calculate(expression, x);
        x += dx;
    }

    char graph[HEIGTH][WIDTH];
    for (int i = 0; i < HEIGTH; i++)
        for (int j = 0; j < WIDTH; j++) graph[i][j] = '.';

    for (int j = 0; j < WIDTH; j++) {
        double y = -1;
        for (int i = 0; i < HEIGTH; i++) {
            if (fabs(values[j] - y) <= dy / 2) {
                graph[i][j] = '*';
                i = HEIGTH;
            } else
                y += dy;
        }
    }

    for (int i = 0; i < HEIGTH; i++) {
        for (int j = 0; j < WIDTH; j++) printf("%c", graph[i][j]);
        printf("\n");
    }
}