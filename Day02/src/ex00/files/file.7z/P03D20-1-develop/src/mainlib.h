#ifndef MAINLIB_H
#define MAINLIB_H

#define WIDTH 80
#define HEIGTH 25

struct pri_op {
    char operator;
    int priority;
};

int my_isdigit(char ch);
double calculate(char *expression, double x);
void build_graph(char *expression);


int priority(char);
int my_isdigit(char ch);

#endif